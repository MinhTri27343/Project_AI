#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


int main(int argc, char *argv[])
{
  char buffer[100];
  int pipe_p_c[2];
  int pipe_c_p[2];
  char ping[4] = "ping";
  char pong[4] = "pong";
  pde_t id_create;
  
  if(pipe(pipe_p_c) == -1)
  { 
      printf("Cannot create pipe");
      exit(1);
  }
   if(pipe(pipe_c_p) == -1)
  {
      printf("Cannot create pipe");
      exit(1);
  }
  
  id_create = fork();
  if(id_create < 0)
  {
      printf("Cannot create child process");
      exit(1);
  }
  
  if(id_create == 0)// Child process
  {
    // Neu chua co input de doc thi se bi block cho toi khi co input 
    
        read(pipe_p_c[0], buffer, sizeof(buffer));
        close(pipe_p_c[0]);
        pde_t id_child = getpid();
        
        printf("%ld: received %s\n", id_child, buffer);
        
        write(pipe_c_p[1], &pong, sizeof(pong));
        close(pipe_c_p[1]);
        exit(0);
  }
  else // Parent process
  {
         
        write(pipe_p_c[1], &ping, sizeof(ping));
        close(pipe_p_c[1]);
        
        read(pipe_c_p[0], buffer, sizeof(buffer));
        close(pipe_c_p[0]);
        pde_t id_parent = getpid();
        printf("%ld: received %s\n", id_parent, buffer);
        exit(0);
  }

}