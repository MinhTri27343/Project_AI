#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define MAXPRIME 280

int generateNumbers();
int generateNew(int, int);
int main(int argc, char *argv[])
{
  int buffer;
  int n = generateNumbers();
  while(read(n, &buffer, sizeof(int)))
  {
          printf("prime %d\n", buffer);
          n = generateNew(n, buffer);
  }
  exit(0);
}

int generateNumbers()
{
       int p[2];
       if(pipe(p) == -1)
       {    
            printf("GenerateNumbers cannot create pipe\n");
            exit(1);
       }
       if(fork() == 0)
       {
            for(int i = 2; i < MAXPRIME; i++)
            {    
                  write(p[1], &i, sizeof(int));   
            }   
            close(p[1]);
            exit(0);
       }
      
        close(p[1]);
       return p[0];
}

int generateNew(int p_in, int prime )
{
    int p_out[2];
    int buffer;
    if(pipe(p_out) == -1)
       {    
            printf("generateNew cannot create pipe\n");
            exit(1);
       }
    if(fork() == 0)
    {     
          
          while(read(p_in, &buffer, sizeof(int)))
          {
              if(buffer % prime != 0)
              {
                  write(p_out[1], &buffer, sizeof(int));
              }
          }
          close(p_in);
          close(p_out[1]);
          exit(0);
    }
    close(p_in);
    close(p_out[1]);
    return p_out[0];
}