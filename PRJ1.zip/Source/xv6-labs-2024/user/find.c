#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"
#include "kernel/param.h"
void find(char* path, char* fileName, int* found);
char*
fmtname(char *path)
{
  static char buf[DIRSIZ+1]; //Tạo 1 buffer có size lớn nhất là dung lượng lớn nhất có thể có
  char *p;

  // Find first character after last slash.
  for(p=path+strlen(path); p >= path && *p != '/'; p--) //Trỏ con trỏ p đến file cần tìm và bỏ qua thư mục. Vd như ./a/b thì trỏ tới b
    ;
  p++;

  // Return name, ended with a null character; now we have a
  // proper C string
  if(strlen(p) >= DIRSIZ) //Nếu như file đó lớn hơn dung lượng lớn nhất có thể có thì cook
    return p;
  memmove(buf, p, strlen(p)); //Copy phần p đó vào buffer
  memset(buf+strlen(p), '\0', DIRSIZ-strlen(p));//Điền \0 vào phần còn lại của mảng buff 
  return buf;
}
void processFile(char* buff, char* fileName, int* found){
  if (strcmp(fmtname(buff), fileName) == 0) { //Nếu như đường dẫn đang kiếm tồn tại (fmtname(buff) là tên file) thì in ra luôn
     printf("%s\n", buff);
    *found = 1;
  }
}
void processDirectory(char* buff, char* fileName, int* found){
  if(strcmp(fmtname(buff), ".") != 0 && strcmp(fmtname(buff), "..") != 0){ //Nếu như cái thư mục đó không phải là . hoặc .. thì đi vào bên trong
    find(buff, fileName, found); 
  }
}
void find(char* path, char* fileName, int* found)
{ 
    char buff[MAXPATH];//chứa đường dẫn đầy đủ
    int fd;//Mô tả file (File description)
    struct dirent de; //Viết tắt: Directory entry. Thông tin entry trong thư mục. Ví dụ như folder A có file A, B, C thì B năm ở entry 2
    struct stat st; //Viết tắt: Status. Thông tin về loại file(Tập tin / thư mục)

    //DIRSIZ là một hằng số định nghĩa độ dài tối đa của tên file (hoặc tên thư mục) trong hệ điều hành xv6. 
    //Kiểm tra xem đường dẫn + / + tên file thì không vượt quá size của buffer. 
    if(strlen(path) + 1 + DIRSIZ > sizeof(buff)){
      fprintf(2, "Find: Path too long. Can't find\n");
      return;
    }
    //Kiểm tra xem đường dẫn có tồn tại?
    if((fd = open(path, O_RDONLY)) < 0){
        fprintf(2, "Find: Cannot open %s\n", path);
        return;
    }
    // printf("%ld", fd); //fd thứ 3, 4, 5.. được mở. 0, 1, 2 lần lượt là stdin, stdout, stderr
    //Lấy thông tin về loại file (Tập tin hay thư mục và lưu vào st)
    if(fstat(fd, &st) < 0){ //
        fprintf(2, "Find: Cannot stat %s\n", path);
        close(fd);
        return;
    }
    // printf("%d %ld\n", st.type, st.size);
    //Copy đường dẫn vào buffer
    strcpy(buff, path); //Gán đường dẫn path vào buffer
    char* p = buff + strlen(buff); //sau đó dịch chuyển con trỏ 1 đến cuối(ở vị trí \0) và thêm dấu / vào
    *p++ = '/'; //sau đó dịch con trỏ lên thêm 1 đoạn
    while(read(fd, &de, sizeof(de)) == sizeof(de)) //Đọc entry từ thư mục đang mở nếu như kích thước đọc được bằng sizeof(de) thì thông tin hợp lệ là được đọc
    {

        // printf("%s %d %s\n", path, de.inum, de.name); lưu thông tin entry của file
        if(de.inum == 0) //Entry không hợp lê
          continue;
        //Lưu thông tin vào p
        memmove(p, de.name, DIRSIZ); //gán tên file từ de.name(tên file vd như find, pingpong) vào đường dẫn path(buff)
        // printf("%d %s %d %s\n", strlen(p), p, strlen(buff), buff);
        p[DIRSIZ] = '\0';
        printf("%s\n", buff);
        if(stat(buff, &st) < 0){ //Lấy thông tin của file mới từ đường dẫn mới
          printf("Ls: Cannot stat %s\n", buff);
          continue;
        }
        switch(st.type){ //Kiểm tra loại file
            case T_FILE: //Nếu như nó là file thì xử lý
            {
                processFile(buff, fileName, found); //Truyền vào đường dẫn file, tên file và biến kiểm tra có tồn tại file hay không
            }break;
            case T_DIR: //Nếu như nó là directory thì xử lý(có đệ quy để đi vào bên trong)
            {
                processDirectory(buff, fileName, found); //Truyền vào đường dẫn file, tên file và biến kiểm tra có tồn tại file hay không
            }break;
        }
      }
      close(fd);
}
int
main(int argc, char *argv[])
{
  if(argc != 3){
    printf("Please follow the requirement\n");
    exit(1);
  }
  int found = 0;
  find(argv[1], argv[2], &found); 
  if(found == 0){
    printf("Find: No such file found\n");
  }
  exit(0);
}