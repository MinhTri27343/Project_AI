#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"  

// Thực thi lệnh với danh sách tham số
void execute_command(char *arguments[])
{
    // fork() tạo ra một tiến trình con (child process). Trong tiến trình con thì fork trả về 0 --> !fork() = true
    if (!fork()) {
        exec(arguments[0], arguments); // Thực thi đoạn mã 
        exit(1); // Thoát nếu exec thất bại
    }
    wait(0);  // Đợi tiến trình con chạy xong rồi tiến trình cha chạy (tiến trình cha là shell)
}

// Xử lý đầu vào từ stdin, tách thành các đối số và thực thi lệnh
void process_input(char *input_buffer, char *arguments[], int argument_index_to_push_origin)
{
    // Trỏ current_argument bắt đầu từ đầu vùng bộ nhớ input_buffer. Mỗi lần tìm được một đối số mới, con trỏ này sẽ được cập nhật đến phần tiếp theo trong input_buffer.
    char *current_argument = input_buffer; 
    char character;
    int argument_index_to_push_current = argument_index_to_push_origin; // Luu index trong mang argument[] de them doi so moi 
    int buffer_offset = 0; // Vị trí tiếp theo để ghi vào trong input_buffer

    // Vòng lặp đọc từng ký tự từ stdin (file descriptor 0)
    while (read(0, &character, 1) > 0) {
        // Nếu gặp khoảng trắng và chỉ xử lý khi dã đọc được ít nhất 1 kí tự .
        if (character == '\n' && buffer_offset > 0) {
            // Kết thúc chuỗi bằng ký tự \0 (null-terminator)
            input_buffer[buffer_offset++] = '\0';
            // Thêm con trỏ đến chuỗi current_argument vào mảng arguments.
            arguments[argument_index_to_push_current++] = current_argument;
            // Cập nhật current_argument để trỏ đến vị trí tiếp theo trong bộ đệm, chuẩn bị đọc đối số mới.
            current_argument = input_buffer + buffer_offset;
            // Kết thúc chuỗi bằng ký tự \0 (null-terminator)
            arguments[argument_index_to_push_current] = '\0';
            // Thực thi câu lệnh 
            execute_command(arguments);
            // Cập nhật lại arument_index
            argument_index_to_push_current = argument_index_to_push_origin;
            // Cập nhật lại số lượng batch hiện tại 
        }
        else {
            // Đọc từng  kí tự input và lưu vào input_buffer 
            input_buffer[buffer_offset++] = character;

        }
    }
}

int main(int argc, char *argv[])
{
    if (argc <= 1) {
        fprintf(2, "usage: xargs [-n max_args] <command> [argv...]\n");
        exit(1);
    }

    // #define MAXARG       32  // max exec arguments
    int command_start_index = 1;

    // Kiểm tra tùy chọn -n để giới hạn số lượng tham số mỗi lần thực thi
    if (argc > 2 && strcmp(argv[1], "-n") == 0) {
        command_start_index = 3;
    }

    char input_buffer[2048];
    char *arguments[MAXARG];

    // Sao chép các tham số của lệnh vào danh sách đối số
    for (int i = command_start_index; i < argc; i++) {
        arguments[i - command_start_index] = argv[i];
    }
    arguments[argc - command_start_index] = '\0';
    
    process_input(input_buffer, arguments, argc - command_start_index);
    exit(0);
}