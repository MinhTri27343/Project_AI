1) Level 5, 6 thì không có phần report time, memory. Cho nên là InfoRecord không có ở level 5-6.
2) Level 1-5 thì chỉ cần search 1 lần và sau đó di chuyển đến đó.
3) IDS trong level 1-5 thì search hết map. Cho nên là thuật toán IDS trong level 1-5 phải khác thuật toán ở level 6.
4) Ở level 1-5 thì không có lưu vào leaderboard.
