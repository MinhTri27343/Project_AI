#ifndef SYSINFO_H
#define SYSINFO_H
uint64 freeMemory(void);
uint64 numberProcess(void);
uint64 loadAverage(void);
struct sysinfo {
    uint64 freemem;  // Số byte bộ nhớ còn trống
    uint64 nproc;    // Số lượng tiến trình đang chạy
    uint64 loadAverage; // Tải trung bình hệ thống
};


#endif